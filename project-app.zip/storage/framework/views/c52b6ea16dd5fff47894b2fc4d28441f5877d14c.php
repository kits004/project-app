
<?php $__env->startSection('content'); ?>
  
    <div class="card">
    <div class="card-header text-white" style="background-color:  	#650dff;">Sample Form</div>
        <div class="card-header" style="background-color:#9308ee">
        <body>
           <div class="card-body">
        <div style="background-color:#9308ee">
      <center><h2 style="color:white;"> SAMPLE WEBSITE PROJECT </h2>
        <h1><a href=http://google.com><div class="card-body" style="background-color:black;">CLICK HERE TO DIRECT MY GITHUB</a></h1>
        </body>
        </center>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Jeric\project-app\resources\views/login/home.blade.php ENDPATH**/ ?>