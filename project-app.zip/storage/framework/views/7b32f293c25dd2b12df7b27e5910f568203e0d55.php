
<?php $__env->startSection('content'); ?>
  
    <div class="card">
        <div class="card-header">Contact Form</div>
        <div class="card-body"> 
           <h2> Thanks You !!!!!!! </h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Jeric\project-app\resources\views/contact/thanks.blade.php ENDPATH**/ ?>