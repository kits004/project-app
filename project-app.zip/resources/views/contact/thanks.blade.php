@extends('layout')
@section('content')
  
    <div class="card">
        <div class="card-header">Sample Form</div>
        <div class="card-body"> 
           <h2> Thanks You !!!!!!! </h2>
        </div>
    </div>
@stop