@extends('layout')
@section('content')
  
    <div class="card">
    <div class="card-header text-white" style="background-color:  	#650dff;">Sample Form</div>
        <div class="card-header" style="background-color:#9308ee">
        <body>
           <div class="card-body">
        <div style="background-color:#9308ee">
      <center><h2 style="color:white;"> SAMPLE WEBSITE PROJECT </h2>
        <h1><a href=https://github.com/kits004/project-app.git><div class="card-body" style="background-color:black;">CLICK HERE TO DIRECT MY GITHUB</a></h1>
        </body>
        </center>
        </div>
    </div>
@stop